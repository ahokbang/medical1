shape_list = ["spade", 'diamond', 'heart', 'clover']
print(shape_list)