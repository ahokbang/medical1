# 복습

print("hello world1")
print("hello world2")

print(5 > 15)

print(not True)
print(6*10)
print('6'*10)

print("숫자는 %d" %20)
print("07%d" %123456)
print("0%7d" %123456)
print("%07d" %123456)

print("%5.3f" %3.141952)
print("%05.3f" %3.141952)
print("%05.3f" %3.14)
print("%07.3f" %3.141952)

print("%s" %"a")

print("{}-{}-{}" .format(1,3.14, "안녕"))

# \n: 행이 나눠짐
# \t: 띄어쓰기

# 따옴표 사용하기
print("철수가 말했습니다. \"영희의 생각은 어떨까?\"")

print("a는 %s입니다." %"입력값")
