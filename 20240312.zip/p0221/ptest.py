num = input("숫자를 입력하세요 >> ")
num = int(num)
# print("입력하신 숫자는 ",num ,"입니다")

print("입력하신 숫자는 ",int(num)+1 ,"입니다")