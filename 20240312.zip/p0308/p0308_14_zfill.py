ss = "123"
print("1234567890")
print(ss.center(10)) # 빈 가운데정렬
print(ss.center(10), "*") # 빈공백을 *로 넣고 가운데정렬
print(ss.rjust(10)) # 오른쪽정렬
print(ss.ljust(10)) # 왼쪽정렬
print(ss.zfill(10)) # 나머지 빈 공백 전부 0으로 채워줌 # 상대적으로 많이 사용
