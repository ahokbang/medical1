print('hello world 1')
print("hellow world 2")

print("hi")
print(123) #숫자는 따옴표 안써도 돼
print(-20)
print(3.14)

print("안녕")
print("안녕안녕안녕")
print("안녕*10")
print("안녕"*10) # 따옴표 끝나고 * 

# 주석; 메모할 때 사용, 샵 없이 사용하면 error 발생. 컴퓨터가 이해 못해

# ,로 두개를 연결할 수 있다. 숫자도 가능
print("안녕하세요. 반갑습니다.")
print("안녕하세요.", "반갑습니다.")
print(1, 2)
print(30, "살입니다.")
print('안녕', 'hi', 'hello') # , 사용하면 무조건 한 칸 띄어진다.

# +를 사용해서 연결할 수 있다. 
# +를 사용하면 띄어쓰기가 없다.
print('안녕하세요' + '반갑습니다')
print('30'+"살입니다") # + 사용할 때는 숫자에 따옴표 있어야 해. 또는 str 사용
print(str(30)+'살입니다')



