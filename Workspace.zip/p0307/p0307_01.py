'''
1) 스네이크 케이스 : 언더바를 사용
stu_name
2) 캐멀 케이스 : 단어 첫글자를 대문자 사용

자료형
stu_name = "홍길동" # str 타입
stu_no = 1 # 숫자 int 타입
print(type(sut_no))
print(type(stu_name))
으로 type 확인할 수 있어.
s # 타입 없어
변수를 지정할 땐 타입을 지정해야 해

int stuNo # 변수 앞에 타입 지정

'''


