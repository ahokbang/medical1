# 함수선언
def plus(v1, v2) :
    result = 0
    result = v1 + v2
    return result

# 함수호출
hap = plus(100,200)
print(hap)
# 또는 위의 2개를 합쳐서 아래와 같이 쓸 수 있어.
print(plus(100,200))
print("프로그램 종료")